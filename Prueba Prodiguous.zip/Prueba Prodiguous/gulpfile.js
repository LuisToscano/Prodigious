var gulp = require('gulp');
var gutil = require('gulp-util');
var bower = require('bower');
var concat = require('gulp-concat');
var sass = require('gulp-sass');
var minifyCss = require('gulp-minify-css');
var rename = require('gulp-rename');
var sh = require('shelljs');
var ugly = require('gulp-uglify');
var ngAnnotate = require('gulp-ng-annotate');

var paths = {
    sass: './scss/**/*.scss',
    js: './app/**/*.js',
    sassDest : './www/css/',
    sassOrigin: './scss/ionic.app.scss',
    uglyJsMin: './base/concat',
    uglyJsDest: './www/js/',
    uglyJsFileName: 'main.js'
};

var gulpConstants = {
    tasks: {
        uglyJs: 'ugly-js',
        sass : 'sass'
    },
    extensions: {
        sassResult: '.min.css',
        uglyJsResult: '.min.js'
    }
}

gulp.task('default', ['watch']);

gulp.task(gulpConstants.tasks.sass, function (done) {
    gulp.src(paths.sassOrigin)
            .pipe(sass())
            .on('error', sass.logError)
            .pipe(gulp.dest(paths.sassDest))
            .pipe(minifyCss({
                keepSpecialComments: 0
            }))
            .pipe(rename({extname: gulpConstants.extensions.sassResult}))
            .pipe(gulp.dest(paths.sassDest))
            .on('end', done);
});

gulp.task(gulpConstants.tasks.uglyJs, function (done) {
    gulp.src(paths.js)
            .pipe(concat('concat.js'))
            .pipe(ngAnnotate())
            .on('error', gutil.log)
            .pipe(rename({extname: gulpConstants.extensions.uglyJsResult}))
            .pipe(gulp.dest(paths.uglyJsMin))
            .pipe(ugly())
            .on('error', gutil.log)
            .pipe(rename(paths.uglyJsFileName))
            .pipe(gulp.dest(paths.uglyJsDest))
            .on('end', done);
});

gulp.task('watch', function () {
    gulp.watch(paths.sass, [gulpConstants.tasks.sass]);
    gulp.watch(paths.js, [gulpConstants.tasks.uglyJs]);
});

gulp.task('install', ['git-check'], function () {
    return bower.commands.install()
            .on('log', function (data) {
                gutil.log('bower', gutil.colors.cyan(data.id), data.message);
            });
});

gulp.task('git-check', function (done) {
    if (!sh.which('git')) {
        console.log(
                '  ' + gutil.colors.red('Git is not installed.'),
                '\n  Git, the version control system, is required to download Ionic.',
                '\n  Download git here:', gutil.colors.cyan('http://git-scm.com/downloads') + '.',
                '\n  Once git is installed, run \'' + gutil.colors.cyan('gulp install') + '\' again.'
                );
        process.exit(1);
    }
    done();
});
