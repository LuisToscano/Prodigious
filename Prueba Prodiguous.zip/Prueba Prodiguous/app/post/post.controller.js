/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

(function () {
    angular.module('mobileTest').controller("postController", postController);
    postController.$inject = ['$posts', '$constants', '$ionicModal', '$ionicPopup', '$scope', '$ionicLoading'];
    function postController($posts, $constants, $ionicModal, $ionicPopup, $scope, $ionicLoading) {

        var vm = this;
        vm.constants = $constants.getConstants();
        vm.posts = [];
        vm.search = '';
        vm.curPost = {};
        vm.postListEmpty = postsEmpty;
        vm.toggleInfoVisible = toggleInfo;
        vm.toggleFavPost = toggleFav;
        vm.title = vm.constants.views.index.titleMain;
        vm.byWhomTag = function (user, time) {return String.format(vm.constants.views.post.byWhom, user, time)};
        vm.isFavorite = function(post) { return post.hasOwnProperty('isFavorite') && post.isFavorite };
        vm.changeTitle = function(newtitle){vm.title = newtitle};
        vm.favs = [];
        vm.favsEmpty = $posts.isFavEmpty;
        vm.loadPosts = doRefresh;
        vm.showAlert = showPopUp;
        
        doRefresh();
            
        /**
         * Check if vm.posts is empty;
         * @return {Boolean} true if vm.posts is empty. Otherwise, false.
         */
        function postsEmpty() {
            return typeof vm.posts == 'undefined' || vm.posts.length === 0;
        };

        /**
         * Calls 'toggleInfo' method on the posts service.
         * @param {Object} post
         * @return {none}
         */
        function toggleInfo(post) {
            $posts.toggleInfo(post);
        };
        
        function toggleFav(post) {
            $posts.toggleFav(post);
            vm.favs = $posts.getFavs();
        };
        
        function getPostsFailed(response){
            $ionicLoading.hide();
            console.error(vm.constants.messages.connectionFailed, response);
            vm.showAlert();
            vm.posts = $posts.getOldPosts();
        }
        
         function getPostsSucceed(response){
            $ionicLoading.hide();
            $posts.addFavorites(response.data);
            vm.posts = response.data;
        }
        
        function doRefresh(){
            $ionicLoading.show();
            $posts.getPosts().then(getPostsSucceed, getPostsFailed);
            $scope.$broadcast('scroll.refreshComplete');
        }
        
        function showPopUp() {
            var alertPopup = $ionicPopup.alert({
                title: vm.constants.popups.connection.title,
                template: vm.constants.popups.connection.body
            });
        };
    }
})();
