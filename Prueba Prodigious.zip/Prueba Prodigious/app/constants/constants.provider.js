(function () {
    angular.module('mobileTest').service('$constants', postsService);
    function postsService() {

		var self = {
			'getConstants' : getC
		}

        function getC() {
			return {
				'localStorage' : {
					'favPosts' : 'favPosts',
					'oldPosts' : 'oldPosts'
				},
				'messages' : {
					'postDoesntExist' : 'El post no existe',
					'connectionFailed' : 'No se puede conectar con el servicio'
				},
				'providers' : {
					'posts' : {
						'method' : 'GET',
						'url' : 'http://localhost:3000/posts'
					}	
				},
				'views' : {
					'index' : {
						'titleMain' 	: 'Posts',
						'titleFavs' 	: 'Favoritos',
						'noPosts' 		: 'No hay posts para mostrar en el momento',
						'noFavs' 		: 'Aun no hay posts marcados como favoritos. Oprime la estrella al costado de un post para agregarlo.',
						'btnNewPost' 	: 'Nuevo'
					},
					'post' : {
						'byWhom'   : 'Escrito por {0} a las {1}',
					}
				},
				'popups' : {
					'connection' : {
						'title' : 'Error de conexión',
						'body' : 'No es posible conectar con el servidor en este momento, se mostrarán posts almacenados previamente en caché.'
					}
				}
			}
		}

		return self;
    };
})();