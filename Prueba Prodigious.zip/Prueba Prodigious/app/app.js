/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

(function () {
    angular.module('mobileTest', ['ionic']).config(myConfigFunction);
  
  myConfigFunction.$inject = ['$stateProvider','$urlRouterProvider'];  
  function myConfigFunction($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider

  // setup an abstract state for the tabs directive
    .state('tab', {
    url: '/tab',
    abstract: true,
    templateUrl: 'directives/tabs.html'
  })

  // Each tab has its own nav history stack:

  .state('tab.main', {
    url: '/main',
    views: {
      'tab-main': {
        templateUrl: 'directives/tab-main.html'
      }
    }
  }
  )
  .state('tab.favs', {
    url: '/favs',
    views: {
      'tab-favs': {
        templateUrl: 'directives/tab-favs.html'
      }
    }
  }
  );

  // if none of the above states are matched, use this as the fallback
  $urlRouterProvider.otherwise('/tab/main');
}
})();




