
(function () {
    angular.module('mobileTest').service('$posts',postsService);
    postsService.$inject = ['$constants', '$q', '$templateCache', '$http'];
    function postsService($constants, $q, $templateCache, $http) {

        var self = {
            toggleInfo : toggleI,
            toggleFav : toggleF,
            getPosts : getPostsArray,
            getFavs : getFavIds,
            addFavorites : addFavs,
            isFavEmpty : favEmpty,
            getOldPosts : getOld 
        }
        
        var that = this;
        this.constants = $constants.getConstants();
        this.favs = window.localStorage[this.constants.localStorage.favPosts] ? angular.fromJson(window.localStorage[this.constants.localStorage.favPosts]) : [];
        this.oldPosts = window.localStorage[this.constants.localStorage.oldPosts] ? angular.fromJson(window.localStorage[this.constants.localStorage.oldPosts]) : [];
        addFavs(this.oldPosts);

        function getPostsArray(){
            var x = 1;
            return $q(function(resolve, reject) {
            $http({method: that.constants.providers.posts.method, url: that.constants.providers.posts.url, cache: $templateCache}).
                then(function(response){ 
                    window.localStorage[that.constants.localStorage.oldPosts] = JSON.stringify(response.data);
                    resolve(response);
                }, function(response){reject(response)});
            });
        }

        function toggleI(post) {
            post.info_visible = !post.info_visible;
        };
        
        function toggleF(post) {
            post.isFavorite = post.isFavorite ? !post.isFavorite : true;
            if(post.isFavorite){
                that.favs.push(post.id);
            }else{
                var index = that.favs.indexOf(post.id);
                if (index > -1) {
                    that.favs.splice(index, 1);
                }
            }
            window.localStorage[that.constants.localStorage.favPosts] = JSON.stringify(that.favs);
        };
        
        function addFavs(data){
            data.forEach(function(post){
                post.isFavorite = that.favs.indexOf(post.id) >= 0;
            });
        }
        
        function getFavIds(){
            return that.favs;
        }
        
        function favEmpty(){
            return that.favs.length === 0;
        }
        
        function getOld(){
            return that.oldPosts;
        }

        return self;
    };
})();